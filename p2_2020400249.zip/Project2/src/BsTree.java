import java.util.ArrayList;


public class BsTree 
{
	public Node root;
	 
	
	// Constructor for BsTree Class
	public BsTree() 
	{
		root = null;
	}
	
	
	// Adds a new node to the tree and returns its root to node path so that I can log the change.
	public ArrayList<String> addNode(String ipAdress) 
	{
		root = addNode(ipAdress, root);
		ArrayList<String> path = new ArrayList<>();
		searchPath(ipAdress, path, root);
		return path;
	}
	// Deletes the node with given Ip and returns a string for 3 unique situations
	public String delete(String ipAdress)
	{
		ArrayList<String> path = new ArrayList<>();
		Node deletedNode = searchPath(ipAdress, path, root);
		Node copyNode = new Node(ipAdress);
		copyNode.setLeftChild(deletedNode.getLeftChild());
		copyNode.setRightChild(deletedNode.getRightChild());
		root = delete(ipAdress, root);
		if(copyNode.getRightChild() == null && copyNode.getLeftChild() == null) 
		{
			return path.get(path.size()-2) + ": Leaf Node Deleted: " + copyNode.getIpAdress();
		}
		
		else if(copyNode.getRightChild() != null && copyNode.getLeftChild() != null) 
		{	
			return path.get(path.size()-2) + ": Non Leaf Node Deleted; removed: " + copyNode.getIpAdress() + " replaced: " + deletedNode.getIpAdress();
		}
		
		else
		{
			return path.get(path.size()-2) + ": Node with single child Deleted: " + copyNode.getIpAdress();
		}
	}
	// Finds the shortest node_to_node path for given IpAdresses and stores the path in an arraylist, finally returns the arraylist.
	public ArrayList<String> send(String senderIp, String recieverIp) 
	{
		ArrayList<String> senderPath = new ArrayList<>();
		ArrayList<String> recieverPath = new ArrayList<>();
		ArrayList<String> realPath = new ArrayList<>();
		searchPath(senderIp, senderPath, root);
		searchPath(recieverIp, recieverPath, root);
		
		int pointer = -1;
		int i = 0;
		int j = 0;
	
		

		while (i != senderPath.size() && j != recieverPath.size())
		{
			if ((i == j) && senderPath.get(i).equals(recieverPath.get(j))) 
			{
				i++;
				j++;
				pointer = j - 1;
			}
			else 
			{
				break;
			}
		}
		if(pointer == -1) 
		{
			for(i = senderPath.size()-1; i > pointer; i--)
			{
				realPath.add(senderPath.get(i));
			}
		}
		else
		{
			for(i = senderPath.size()-1; i > pointer; i--)
			{
				realPath.add(senderPath.get(i));
			}
			
			for(i = pointer; i < recieverPath.size(); i++) 
			{
				realPath.add(recieverPath.get(i));
			}
		}

		return realPath;
	}
	
	// Helper method for finding minimum element in a given subtree, used in delete method.
	private Node findMin(Node node) 
	{
		if(node == null) 
		{
			return null;
		}
		else if (node.getLeftChild() == null) 
		{
			return node;
		}
		return findMin(node.getLeftChild());
	}
	// Returns the node with given Ip and stores its root_to_node path in an arraylist.
	private Node searchPath(String ipAdress, ArrayList<String> path, Node node)
	{
		
		if(node == null) 
        {
        	return null;
        }
		path.add(node.getIpAdress());
        int result = ipAdress.compareTo(node.getIpAdress());
        if(result < 0) 
        {
            return searchPath(ipAdress, path, node.getLeftChild());
        }
        else if( result > 0 ) 
        {
            return searchPath(ipAdress, path, node.getRightChild());
        }
        else
        {
            return node;
        }
	}
	// Adds a new node to the binary search tree without violating the rules.
	private Node addNode(String ipAdress, Node node)
	{
		if( node == null ) 
		{
			return new Node(ipAdress);
		}

		int result = ipAdress.compareTo(node.getIpAdress());
		
		if(result < 0) 
		{
            node.setLeftChild(addNode(ipAdress, node.getLeftChild()));
		}
        else if( result > 0 ) 
        {
        	node.setRightChild(addNode(ipAdress, node.getRightChild()));
        }
        return node;
    }
	// Deletes the node with given Ip to the binary search tree without violating the rules.
	private Node delete(String ipAdress, Node node)
	{
		if(node == null) 
	    {
			return node;
	    }

	    int result = ipAdress.compareTo(node.getIpAdress());
	    if(result < 0) 
	    {
	    	node.setLeftChild(delete(ipAdress, node.getLeftChild()));
	    }
	    else if(result > 0) 
	    {
	    	node.setRightChild(delete(ipAdress, node.getRightChild()));
	    }
	    else 
	    {
	    	// Leaf or Single child
	    	if(node.getLeftChild() == null) 
	    	{ 
	    		return node.getRightChild();
	    	}
	    	// Single child
	    	else if(node.getRightChild() == null)
	    	{
	    		return node.getLeftChild();
	    	}
	    	// Non-Leaf
	    	node.setIpAdress(findMin(node.getRightChild()).getIpAdress()); 
		    node.setRightChild(delete(node.getIpAdress(), node.getRightChild()));
		    
	    }
	    return node;
	}
}