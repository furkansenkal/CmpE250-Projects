
import java.util.ArrayList;
import java.util.PriorityQueue;




class Acc
{
	public String name;
	public String[] hashAirports = new String[1000];
	public Atc[] hashAtcs = new Atc[1000];
	public ArrayList<String> airports = new ArrayList<>();
	public int time = 0;
	public PriorityQueue<Flight> readyQueue = new PriorityQueue<>(new FlightComparator());
	
	
	public Acc(String name, ArrayList<String> airports) 
	{
		super();
		this.name = name;
		this.airports = airports;
		boolean setFlag = true;
		for(int i=0; i < airports.size(); i++) 
		{
			setFlag = true;
			String airport = airports.get(i);
			int hashValue = 0;
			for(int j=0; j < airport.length(); j++) 
			{
				hashValue += (Math.pow(31,j))*(int)airport.charAt(j);
			}
			while(setFlag) 
			{
				hashValue = hashValue % 1000;
				if(hashAirports[hashValue] != null) 
				{
					hashValue += 1;
					hashValue = hashValue % 1000;
				}
				else
				{
					hashValue = hashValue % 1000;
					setFlag = false;
				}
			}
			String atcName = "";
			if(hashValue >= 100) 
			{
				atcName = name+String.valueOf(hashValue);
			}
			else if((10 <= hashValue) && (hashValue <= 99)) 
			{
				atcName = name+"0"+String.valueOf(hashValue);
			}
			else if(hashValue <= 9) 
			{
				atcName = name+"00"+String.valueOf(hashValue);
			}
			hashAirports[hashValue] = airport;
			hashAtcs[hashValue] = new Atc(atcName, this);
		}
	}
	// ACC class constructor that has name and airports ArrayList.
	// Also calculates hash values of airports and fills hashAirports and hashAtcs arrays according to the hash values.
	
	public void enterFlight() 
	{
		// Method that calculates ACC's finishing time.
		while(!(readyQueue.isEmpty()))
		{
			Flight flight = readyQueue.poll();
			// Takes a flight from Priority queue.
			int tempAdmission;
			flight.firstAdmission = true;
			if(flight.operations.size() == 21 || flight.operations.size() == 19 || flight.operations.size() == 11 || flight.operations.size() == 9) 
			{
				// ACC running operation
				if(flight.admissionTime > time) 
				{
					tempAdmission = flight.admissionTime;
					// ACC is not busy.
				}
				else 
				{
					tempAdmission = time;
					// ACC is busy.
				}
				 
				if(flight.operations.get(0)<=30) 
				{
					flight.admissionTime = tempAdmission+flight.operations.get(0);
					time = tempAdmission+flight.operations.get(0);
					flight.operations.remove(0);
					// Operation time is less than 30, so operation finishes. 
				}
				else 
				{
					flight.firstAdmission = false;
					flight.admissionTime = tempAdmission+30;
					time = tempAdmission+30;
					flight.operations.set(0, flight.operations.get(0)-30);
					// Does operation for 30 time quanta and subtract 30 from flight's operation time.
				}
				readyQueue.add(flight);
				// Adds flight to the queue.
			}
			else if(flight.operations.size() == 20 || flight.operations.size() == 10) 
			{
				flight.admissionTime += flight.operations.get(0);
				flight.operations.remove(0);
				readyQueue.add(flight);
				// ACC waiting operations.
			}
			else if ((18 >= flight.operations.size()) && (flight.operations.size() >= 12)) 
			{
				Atc responsibleAtc = hashAtcs[calculateHash(flight.departureAirport)];
				responsibleAtc.atcOperator(flight);
				readyQueue.add(flight);
				// ATC operations on departure airport ATC.
			}
			else if ((8 >= flight.operations.size()) && (flight.operations.size() >= 2)) 
			{
				Atc responsibleAtc = hashAtcs[calculateHash(flight.arrivalAirport)];
				responsibleAtc.atcOperator(flight);
				readyQueue.add(flight);
				// ATC operations on arrival airport ATC.
			}
			else if(flight.operations.size() == 1) 
			{
				// Last ACC running operation.
				if(flight.admissionTime > time) 
				{
					tempAdmission = flight.admissionTime;
				}
				else 
				{
					tempAdmission = time;
				}
				
				if(flight.operations.get(0)<=30) 
				{
					flight.admissionTime = tempAdmission+flight.operations.get(0);
					time = tempAdmission+flight.operations.get(0);
					flight.operations.remove(0);
					// Last operation finishes, so flight is finished.
				}
				else 
				{
					flight.firstAdmission = false;
					flight.admissionTime = tempAdmission+30;
					time = tempAdmission+30;
					flight.operations.set(0, flight.operations.get(0)-30);
					readyQueue.add(flight);
					// Does operation for 30 time quanta and subtract 30 from flight's operation time.
				}
			}
			
		}
	}
	
	public Integer calculateHash(String airport)
	// Calculates hash value of given airport.
	{
		int hashValue = 0;
		boolean setFlag = true;
		for(int j=0; j < airport.length(); j++) 
		{
			hashValue += (Math.pow(31,j))*(int)airport.charAt(j);
			// Hash function.
		}
		while(setFlag) 
		{
			hashValue = hashValue % 1000;
			if(!(hashAirports[hashValue].equals(airport))) 
			{
				hashValue += 1;
				hashValue = hashValue % 1000;
				// Linear probing.
			}
			else
			{
				hashValue = hashValue%1000;
				setFlag = false;
			}
		}
		return hashValue;
	}
}

