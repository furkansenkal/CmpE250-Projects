
public class Node 
{
	private String ipAdress;
	private Node rightChild;
	private Node leftChild;
	private int height;
	
	// Constructor for Node class
	public Node(String ipAdress) 
	{
		this.ipAdress = ipAdress;
		this.leftChild = null;
		this.rightChild = null;
	}
	// Getters and Setters of Node Class
	public String getIpAdress() 
	{
		return ipAdress;
	}
	public void setIpAdress(String ipAdress) 
	{
		this.ipAdress = ipAdress;
	}
	public Node getRightChild() 
	{
		return rightChild;
	}
	public void setRightChild(Node rightChild) 
	{
		this.rightChild = rightChild;
	}
	public Node getLeftChild() 
	{
		return leftChild;
	}
	public void setLeftChild(Node leftChild) 
	{
		this.leftChild = leftChild;
	}
	public int getHeight() 
	{
		return height;
	}
	public void setHeight(int height) 
	{
		this.height = height;
	}
	

}
