import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class Vertex
{
	
	public String name;
	public boolean isFlag;
	public boolean isCollected = false;
	public boolean isVisited = false;
	public int cost = -1;
	public Map<Vertex, Integer> adjacents = new HashMap<>();
	// Vertex class with name, isFlag, isVisited, isCollected booleans, cost, and HashMap for to store adjacents of vertex.
	
	public Vertex(String name, boolean isFlag) 
	{
		this.name = name;
		this.isFlag = isFlag;
	}
	// Constructor with name and isFlag parameters.
	
	public void addAdjacent(Vertex adjacent, int weight) 
	{
		adjacents.put(adjacent, weight);
		
	}
	// addAdjacent method for adding new adjacent to vertex.

}

class VertexComparator implements Comparator<Vertex>
{
	public int compare(Vertex v1, Vertex v2) 
	{
		if(v1.cost != -1 && v2.cost != -1) 
		{
			if(v1.cost < v2.cost) 
			{
				return -1;
			}
			else if(v1.cost > v2.cost)
			{
				return 1;
			}
			else 
			{
				return 0;
			}
		}
		
		else if (v1.cost != -1 && v2.cost == -1)
		{
			return 1;
		}
		
		else if (v1.cost == -1 && v2.cost != -1)
		{
			return -1;
		}
		else 
		{
			return 0;
		}
	}
}
// Vertex comparator for sort vertices by their costs is priority queue.
