import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


public class project4
{
	public static void main(String[] args) throws IOException
	{
		
		FileReader fReader = new FileReader(args[0]);
		BufferedReader bReader = new BufferedReader(fReader);
		Writer fWriter = new FileWriter(args[1]);
		// Opens Reader and Writer objects.
		
		int vertexNumber = 0;
		int flagNumber = 0;
		// Declares vertex number and flag number.
		
		String startName = null;
		String finishName = null;
		Vertex start = null;
		Vertex finish = null;
		Set<String> flagNames = new HashSet<>();
		Map<String, Vertex> vertices = new HashMap<>();
		// Opens a set to store flag names and a map to store vertices by names and declares start-finish names and vertices.
		
		Graph raceGraph = new Graph();
		// Creates new graph object.
		
		int lineCounter = 0;
		
		while(bReader.ready()) 
		{
			String line = bReader.readLine();
			String[] parts = line.split(" ");
			lineCounter += 1;
			// If there is a line that is not read, reads it and stores its parts in an array.
			
			if(lineCounter == 1) 
			{
				vertexNumber = Integer.parseInt(parts[0]);
			}
			// First line is the number of vertices.
			
			else if(lineCounter == 2) 
			{
				flagNumber = Integer.parseInt(parts[0]);
			}
			// Second line is the number of flags.
			
			else if(lineCounter == 3) 
			{
				startName = parts[0];
				finishName = parts[1];
			}
			// Third line contains start and finish names.
			
			else if(lineCounter == 4) 
			{
				for(int i=0; i < flagNumber; i++) 
				{
					flagNames.add(parts[i]);
				}
			}
			// Fourth line contains flag names.
			
			else 
			{
				if(!vertices.containsKey(parts[0])) 
				{
					if(parts[0].equals(startName)) 
					{
						if(flagNames.contains(startName)) 
						{
							start = new Vertex(startName, true);
							vertices.put(startName, start);
						}
						else 
						{
							start = new Vertex(startName, false);
							vertices.put(startName, start);
						}	
					}
					else if(parts[0].equals(finishName)) 
					{
						if(flagNames.contains(finishName)) 
						{
							finish = new Vertex(finishName, true);
							vertices.put(finishName, finish);
						}
						else 
						{
							finish = new Vertex(finishName, false);
							vertices.put(finishName, finish);
						}	
					}
					else 
					{
						if(flagNames.contains(parts[0])) 
						{
							String vertexName = parts[0];
							Vertex vertex = new Vertex(parts[0], true);
							vertices.put(vertexName, vertex);
						}
						else 
						{
							String vertexName = parts[0];
							Vertex vertex = new Vertex(parts[0], false);
							vertices.put(vertexName, vertex);
						}	
					}
				}
				Vertex currentVertex = vertices.get(parts[0]);
				// If there is no vertex that has the sane name as line's first element creates it.
				// Sets current vertex as the vertex that has the same name as the line's first element.
				
				int counter = 1;
				while(counter < parts.length-1) 
				{
					if(!vertices.containsKey(parts[counter])) 
					{
						if(parts[counter].equals(startName)) 
						{
							if(flagNames.contains(startName)) 
							{
								start = new Vertex(startName, true);
								vertices.put(startName, start);
							}
							else 
							{
								start = new Vertex(startName, false);
								vertices.put(startName, start);
							}	
						}
						else if(parts[counter].equals(finishName)) 
						{
							if(flagNames.contains(finishName)) 
							{
								finish = new Vertex(finishName, true);
								vertices.put(finishName, finish);
							}
							else 
							{
								finish = new Vertex(finishName, false);
								vertices.put(finishName, finish);
							}	
						}
						else 
						{
							if(flagNames.contains(parts[counter])) 
							{
								String vertexName = parts[counter];
								Vertex vertex = new Vertex(parts[counter], true);
								vertices.put(vertexName, vertex);
							}
							else 
							{
								String vertexName = parts[counter];
								Vertex vertex = new Vertex(parts[counter], false);
								vertices.put(vertexName, vertex);
							}	
						}
					}
					// If there is no vertex that has the sane name as line's corresponding element creates it.
					
					currentVertex.addAdjacent(vertices.get(parts[counter]), Integer.parseInt(parts[counter+1]));
					vertices.get(parts[counter]).addAdjacent(currentVertex, Integer.parseInt(parts[counter+1]));
					counter += 2;
					// Adds the vertex that has the same name as the line's corresponding element current vertex's adjacents.
				}
				raceGraph.addVertex(currentVertex);	
				// Adds current vertex to the graph.
			}
		}
		String racePath = String.valueOf(raceGraph.computeRace(start, finish));
		raceGraph.reset();
		String flagPath = String.valueOf(raceGraph.computeFlag());
		// Calculates shortest paths to finish race and collect flags and converts them to string.
		fWriter.write(racePath);
		fWriter.write("\r\n");
		fWriter.write(flagPath);
		fWriter.write("\r\n");
		bReader.close();
		fWriter.close();
		// Writes shortest paths to finish race and collect flags to the output file and closes Reader and Writer objects.
	}
}
