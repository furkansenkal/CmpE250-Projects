import java.util.ArrayList;


public class AvlTree
{

	public Node root;
	
	
	// Constructor for BsTree Class
	public AvlTree() 
	{
		root = null;
	}
	
	
	// Adds a new node to the tree and returns its root to node path and rotations applied in an arraylist so that I can log the change.
	public ArrayList<ArrayList<String>> addNode(String ipAdress) throws NullPointerException
	{
			ArrayList<ArrayList<String>> list = new ArrayList<>();
			ArrayList<String> path = new ArrayList<>();
			ArrayList<String> rotation = new ArrayList<>();
			searchPath(ipAdress, path, root);
			root = addNode(ipAdress, root, rotation);
			list.add(rotation);
			list.add(path);
			return list;
		
	}
	// Deletes the node with given Ip and returns a string for 6 unique situations.
	public String delete(String ipAdress)
	{
		ArrayList<String> path = new ArrayList<>();
		ArrayList<String> rotation = new ArrayList<>();
		Node deletedNode = searchPath(ipAdress, path, root);
		Node copyNode = new Node(ipAdress);
		copyNode.setLeftChild(deletedNode.getLeftChild());
		copyNode.setRightChild(deletedNode.getRightChild());
		root = delete(ipAdress, root, rotation);	
		
		if(copyNode.getRightChild() == null && copyNode.getLeftChild() == null) 
		{
			if(rotation.isEmpty()) 
			{
				return path.get(path.size()-2) + ": Leaf Node Deleted: " + copyNode.getIpAdress();
			}
			else
			{
				String newline = System.getProperty("line.separator");
				String returnString = path.get(path.size()-2) + ": Leaf Node Deleted: " + copyNode.getIpAdress();
				for(int i = 0; i<rotation.size(); i++) 
				{
					returnString = returnString + newline + "Rebalancing: " + rotation.get(i) + " rotation";
				}
				return returnString;
			}
			
		}
		else if(copyNode.getRightChild() != null && copyNode.getLeftChild() != null) 
		{
			if(rotation.isEmpty()) 
			{
				return path.get(path.size()-2) + ": Non Leaf Node Deleted; removed: " + copyNode.getIpAdress() + " replaced: " + deletedNode.getIpAdress();
			}
			else
			{
				String newline = System.getProperty("line.separator");
				String returnString = path.get(path.size()-2) + ": Non Leaf Node Deleted; removed: " + copyNode.getIpAdress() + " replaced: " + deletedNode.getIpAdress();
				for(int i = 0; i<rotation.size(); i++) 
				{
					returnString = returnString + newline + "Rebalancing: " + rotation.get(i) + " rotation";
				}
				return returnString;
			}
		}
		
		else
		{
			if(rotation.isEmpty()) 
			{
				return path.get(path.size()-2) + ": Node with single child Deleted: " + copyNode.getIpAdress();
			}
			else 
			{
				String newline = System.getProperty("line.separator");
				String returnString = path.get(path.size()-2) + ": Node with single child Deleted: " + copyNode.getIpAdress();
				for(int i = 0; i<rotation.size(); i++) 
				{
					returnString = returnString + newline + "Rebalancing: " + rotation.get(i) + " rotation";
				}
				return returnString;
			}
		}
	}
	// Finds the shortest node_to_node path for given IpAdresses and stores the path in an arraylist, finally returns the arraylist.
	public ArrayList<String> send(String senderIp, String recieverIp) 
	{
		ArrayList<String> senderPath = new ArrayList<>();
		ArrayList<String> recieverPath = new ArrayList<>();
		ArrayList<String> realPath = new ArrayList<>();
		searchPath(senderIp, senderPath, root);
		searchPath(recieverIp, recieverPath, root);
		
		int pointer = -1;
		int i = 0;
		int j = 0;
	

		while (i != senderPath.size() && j != recieverPath.size())
		{
			if ((i == j) && senderPath.get(i).equals(recieverPath.get(j))) 
			{
				i++;
				j++;
				pointer = j - 1;
			}
			else 
			{
				break;
			}
		}
		if(pointer == -1) 
		{
			for(i = senderPath.size()-1; i > pointer; i--)
			{
				realPath.add(senderPath.get(i));
			}
		}
		else
		{
			for(i = senderPath.size()-1; i > pointer; i--)
			{
				realPath.add(senderPath.get(i));
			}
			
			for(i = pointer; i < recieverPath.size(); i++) 
			{
				realPath.add(recieverPath.get(i));
			}
		}
		

		return realPath;
		
	}
	// Helper method for finding minimum element in a given subtree, used in delete method.
	private Node findMin(Node node) 
	{
		if(node == null) 
		{
			return null;
		}
		else if (node.getLeftChild() == null) 
		{
			return node;
		}
		return findMin(node.getLeftChild());
	}
	// Returns the node with given Ip and stores its root_to_node path in an arraylist.
	private Node searchPath(String ipAdress, ArrayList<String> path, Node node)
	{
		
		if(node == null) 
        {
        	return null;
        }
		path.add(node.getIpAdress());
        int result = ipAdress.compareTo(node.getIpAdress());
        if(result < 0) 
        {
            return searchPath(ipAdress, path, node.getLeftChild());
        }
        else if( result > 0 ) 
        {
            return searchPath(ipAdress, path, node.getRightChild());
        }
        else
        {
            return node;
        }
	}
	// Adds a new node to the tree without violating the rules.
	// If the rules are violated applies rotation and fixes it. When a rotation is applied stores it in an arraylist.
	private Node addNode(String ipAdress, Node node, ArrayList<String> rotation)
	{
		if( node == null ) 
		{
			return new Node(ipAdress);
		}

		int result = ipAdress.compareTo(node.getIpAdress());
		
		if(result < 0) 
		{
            node.setLeftChild(addNode(ipAdress, node.getLeftChild(), rotation));
		}
        else if( result > 0 ) 
        {
        	node.setRightChild(addNode(ipAdress, node.getRightChild(), rotation));
        }
		
		if(getHeight(node.getLeftChild()) > getHeight(node.getRightChild())) 
		{
			node.setHeight(getHeight(node.getLeftChild())+1);
		}
		else 
		{
			node.setHeight(getHeight(node.getRightChild())+1);
		}
        return rebalance(node, rotation);
    }
	// Deletes the node with given Ip to the tree without violating the rules. 
	// If the rules are violated applies rotation and fixes it. When a rotation is applied stores it in an arraylist.
	private Node delete(String ipAdress, Node node, ArrayList<String> rotation)
	{
		if(node == null) 
	    {
			return node;
	    }

	    int result = ipAdress.compareTo(node.getIpAdress());
	    if(result < 0) 
	    {
	    	node.setLeftChild(delete(ipAdress, node.getLeftChild(), rotation));
	    }
	    else if(result > 0) 
	    {
	    	node.setRightChild(delete(ipAdress, node.getRightChild(), rotation));
	    }
	    else 
	    {
	    	if(node.getLeftChild() == null) 
	    	{ 
	    		return node.getRightChild();
	    	}
	    	else if(node.getRightChild() == null)
	    	{
	    		return node.getLeftChild();
	    	}
	    	node.setIpAdress(findMin(node.getRightChild()).getIpAdress()); 
		    node.setRightChild(delete(node.getIpAdress(), node.getRightChild(), rotation));
		    
	    }
	    if(getHeight(node.getLeftChild()) > getHeight(node.getRightChild())) 
		{
			node.setHeight(getHeight(node.getLeftChild())+1);
		}
		else 
		{
			node.setHeight(getHeight(node.getRightChild())+1);
		}
	    return rebalance(node, rotation);
	}
	// Helper method for finding the height of a given tree (I used it to get rid of null pointer exception when the node is null.)
	private int getHeight(Node node) 
	{
		if(node == null)
		{
			return -1;
		}
		return node.getHeight();
	}
	// Method for checking the balance of the tree after each add and delete operation 
	// and if the tree is unbalanced applying necessary rotations to provide conditions.
	private Node rebalance(Node node,ArrayList<String> rotation) 
	{
		
		if(getHeight(node.getRightChild()) - getHeight(node.getLeftChild()) < -1) 
		{
			if(getHeight(node.getLeftChild().getRightChild()) - getHeight(node.getLeftChild().getLeftChild()) <= 0) 
			{
				rotation.add("right");
				node = rotateRight(node);
			}
			else 
			{
				rotation.add("left-right");
				node.setLeftChild(rotateLeft(node.getLeftChild()));
				node = rotateRight(node);
			}
		}
		
		if(getHeight(node.getRightChild()) - getHeight(node.getLeftChild()) > 1) 
		{
			if(getHeight(node.getRightChild().getRightChild()) - getHeight(node.getRightChild().getLeftChild()) >= 0) 
			{
				rotation.add("left");
				node = rotateLeft(node);
			}
			else 
			{
				rotation.add("right-left");
				node.setRightChild(rotateRight(node.getRightChild()));
				node = rotateLeft(node);
			}
		}
		return node;
	}
	// Helper method for rebalance method.
	// Applies right rotation. 
	private Node rotateRight(Node node) 
	{
		Node left = node.getLeftChild();
		node.setLeftChild(left.getRightChild());
		left.setRightChild(node);
		
		if(getHeight(node.getLeftChild()) > getHeight(node.getRightChild())) 
		{
			node.setHeight(getHeight(node.getLeftChild())+1);
		}
		else 
		{
			node.setHeight(getHeight(node.getRightChild())+1);
		}
		
		if(getHeight(left.getLeftChild()) > getHeight(left.getRightChild())) 
		{
			left.setHeight(getHeight(left.getLeftChild())+1);
		}
		else 
		{
			left.setHeight(getHeight(left.getRightChild())+1);
		}
		return left;
	}
	// Helper method for rebalance method.
	// Applies right rotation.
	private Node rotateLeft(Node node) 
	{
		Node right = node.getRightChild();
		node.setRightChild(right.getLeftChild());
		right.setLeftChild(node);
		
		if(getHeight(node.getLeftChild()) > getHeight(node.getRightChild())) 
		{
			node.setHeight(getHeight(node.getLeftChild())+1);
		}
		else 
		{
			node.setHeight(getHeight(node.getRightChild())+1);
		}
		
		if(getHeight(right.getLeftChild()) > getHeight(right.getRightChild())) 
		{
			right.setHeight(getHeight(right.getLeftChild())+1);
		}
		else 
		{
			right.setHeight(getHeight(right.getRightChild())+1);
		}

		return right;
	}
}
