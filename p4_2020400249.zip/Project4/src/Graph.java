import java.util.HashSet;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Set;


public class Graph 
{
	public Set<Vertex> graphVertices = new HashSet<>();
	public Set<Vertex> flagVertices = new HashSet<>();
	Vertex startFlag;
	PriorityQueue<Vertex> heap = new PriorityQueue<>(new VertexComparator());
	// Graph class with graphVertices and flagVertices sets to store vertices and flags
	// startFlag vertex to store starting flag.
	// Priority queue for implement dijkstra's algorithm.
	
	public Graph() 
	{
		super();
	}
	// Default constructor.
	
	public void addVertex(Vertex vertex) 
	{
		graphVertices.add(vertex);
		if(vertex.isFlag) 
		{
			if(startFlag == null) 
			{
				startFlag = vertex;
			}
			flagVertices.add(vertex);
		}
	}
	// addVertex method for adding new vertex to the graph, if vertex is flag then adds it to the flag vertices.
	// If startFlag is null sets.
	
	public int computeRace(Vertex start, Vertex finish) 
	{
		start.cost = 0;
		// Sets starting vertex's cost to 0.
		Set<Vertex> usedVertices = new HashSet<>();
		heap.add(start);
		// Creates usedVertices set to store visited vertices.
		// Adds starting vertex to priority queue.
		
		while(usedVertices.size() < graphVertices.size()) 
		{
			if(heap.isEmpty()) 
			{
				break;
			}
			// If priority queue is empty there is no vertex to calculate cost.
			
			Vertex currentVertex = heap.poll();
			// Current vertex is the vertex with the lowest cost in heap.
			
			if(currentVertex.isVisited) 
			{
				continue;
			}
			// If current vertex is already visited skipping the rest of loop.
			
			usedVertices.add(currentVertex);
			currentVertex.isVisited = true;
			// Set current vertex to be visited and add it to the set.
			
			for(Entry<Vertex, Integer> adjacentPair: currentVertex.adjacents.entrySet()) 
			{
				int weight = adjacentPair.getValue();
				Vertex adjacentVertex = adjacentPair.getKey();
				if(!adjacentVertex.isVisited) 
				{
					if((currentVertex.cost + weight < adjacentVertex.cost) || (adjacentVertex.cost == -1)) 
					{
						adjacentVertex.cost = currentVertex.cost + weight;
					}
					heap.add(adjacentVertex);
				}
				// Looks current vertex's adjacents, if an adjacent is not visited updates its cost and adds it to the queue.
			}
		}
		return finish.cost;
		// When all vertices are finished the costs are the shortest paths' costs from the starting vertex.
		// So finishing vertex's cost is the shortest path's cost from start to finish.
		// Returns finishing vertex's cost.
	}
	
	public int computeFlag() 
	{
		
		int totalCost = 0;
		
		Set<Vertex> usedFlags = new HashSet<>();
		usedFlags.add(startFlag);
		startFlag.isCollected = true;
		// Creates usedFlags set to store visited flags and adds starting flag to it.
		// Sets starting flag as collected.
		boolean isBraked = true;
		
		while(usedFlags.size() < flagVertices.size()) 
		{
			if(!isBraked) 
			{
				return -1;
			}
			// If inner loop is not finished by finding next flag that means there is no way to collect flags.
			// So returns -1.
			isBraked = false;
			// Applying a modified dijkstra to the starting flag.
			startFlag.cost = 0;
			Set<Vertex> usedVertices = new HashSet<>();
			heap.add(startFlag);
			while(usedVertices.size() < graphVertices.size()) 
			{
				if(heap.isEmpty()) 
				{
					break;
				}
				// If priority queue is empty there is no vertex to calculate cost.
				
				Vertex currentVertex = heap.poll();
				// Current vertex is the vertex with the lowest cost in heap.
				
				if(currentVertex.isVisited) 
				{
					continue;
				}
				// If current vertex is already visited skipping the rest of loop.
				
				usedVertices.add(currentVertex);
				currentVertex.isVisited = true;
				// Set current vertex to be visited and add it to the set.
				
				for(Entry<Vertex, Integer> adjacentPair: currentVertex.adjacents.entrySet()) 
				{
					int weight = adjacentPair.getValue();
					Vertex adjacentVertex = adjacentPair.getKey();
					if(!adjacentVertex.isVisited) 
					{
						if((currentVertex.cost + weight < adjacentVertex.cost) || (adjacentVertex.cost == -1)) 
						{
							adjacentVertex.cost = currentVertex.cost + weight;
						}
						heap.add(adjacentVertex);
					}
					// Looks current vertex's adjacents, if an adjacent is not visited updates its cost and adds it to the queue.
				}
				if((currentVertex.isFlag) && (!currentVertex.isCollected)) 
				{
					Vertex nextFlag = currentVertex;
					totalCost += nextFlag.cost;
					nextFlag.addAdjacent(startFlag, 0);
					startFlag.addAdjacent(nextFlag, 0);
					usedFlags.add(nextFlag);
					nextFlag.isCollected = true;
					startFlag = nextFlag;
					isBraked = true;
					break;
				}
				// This if block is the difference from normal dijkstra algorithm that used in computeRace method.
				// If current vertex is a not collected flag then adds its cost to total
				// Adds an edge between starting flag and this flag.
				// Adds this flag to the collected flags' set and sets isCollected to true.
				// Sets this flag to be starting flag.
			}
			reset();
			// Resets costs of all vertices and priority queue.
		}
		return totalCost;
		// Returns total cost to collect all flags.
	}
	
	public void reset() 
	{
		for(Vertex vertex : graphVertices) 
		{
			if(vertex.cost != -1) 
			{
				vertex.cost = -1;
			}
			if(vertex.isVisited) 
			{
				vertex.isVisited = false;
			}
		}
		heap.clear();
	}
	// Method for setting costs of vertices to -1 and clearing priority queue.
	
}
