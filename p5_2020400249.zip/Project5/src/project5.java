import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;


public class project5 
{
	
	public static void main(String[] args) throws IOException
	{
		
		FileReader fReader = new FileReader(args[0]);
		BufferedReader bReader = new BufferedReader(fReader);
		Writer fWriter = new FileWriter(args[1]);
		// Opens Reader and Writer objects.
		int vertexNumber = 0;
		int cityNumber = 0;
		int lineCounter = 0;
		Graph graph = null;
		
		while(bReader.ready()) 
		{
			String line = bReader.readLine();
			String[] parts = line.split(" ");
			lineCounter += 1;
			// If there is a line that is not read, reads it and stores its parts in an array.
			
			if(lineCounter == 1) 
			{
				vertexNumber = Integer.parseInt(parts[0]) + 8;
				cityNumber = Integer.parseInt(parts[0]);
				graph = new Graph(vertexNumber);
				graph.verticesNumber = vertexNumber;
				Vertex mainSource = new Vertex("mainSource");
				Vertex s0 = new Vertex("s0");
				Vertex s1 = new Vertex("s1");
				Vertex s2 = new Vertex("s2");
				Vertex s3 = new Vertex("s3");
				Vertex s4 = new Vertex("s4");
				Vertex s5 = new Vertex("s5");
				graph.addVertex(mainSource);
				graph.addVertex(s0);
				graph.addVertex(s1);
				graph.addVertex(s2);
				graph.addVertex(s3);
				graph.addVertex(s4);
				graph.addVertex(s5);
				for(int i = 0; i < cityNumber; i++) 
				{
					graph.addVertex(new Vertex("c".concat(String.valueOf(i))));
				}
				Vertex sink = new Vertex("KL");
				graph.addVertex(sink);
				
				
			}
			// First line is the number of vertices, + 8 because there exists 6 regions 1 Kings Landing and 1 main imaginary source to maintain code.
			// I also created graph with regions, cities and KL.
			else if(lineCounter == 2) 
			{
				
				graph.vertices[0].addAdjacent(graph.vertices[1], Integer.valueOf(parts[0]));
				graph.vertices[0].addAdjacent(graph.vertices[2], Integer.valueOf(parts[1]));
				graph.vertices[0].addAdjacent(graph.vertices[3], Integer.valueOf(parts[2]));
				graph.vertices[0].addAdjacent(graph.vertices[4], Integer.valueOf(parts[3]));
				graph.vertices[0].addAdjacent(graph.vertices[5], Integer.valueOf(parts[4]));
				graph.vertices[0].addAdjacent(graph.vertices[6], Integer.valueOf(parts[5]));
			}
			// Adding imaginary road between imaginary source and regions.
			
			else if(lineCounter >= 3) 
			{
				int counter = 2;
				if(parts[0].charAt(0) == 'r') 
				{
					
					while(counter <= parts.length-1) 
					{
						if(parts[counter-1].charAt(0) == 'c') 
						{
							graph.vertices[Integer.valueOf(parts[0].replace("r", "")) + 1].addAdjacent(graph.vertices[Integer.valueOf(parts[counter-1].replace("c", "")) + 7], Integer.valueOf(parts[counter]));
						}
						else if(parts[counter-1].equals("KL")) 
						{
							graph.vertices[Integer.valueOf(parts[0].replace("r", "")) + 1].addAdjacent(graph.vertices[vertexNumber-1], Integer.valueOf(parts[counter]));
						}
						counter += 2;
					}
					
				}
				else if(parts[0].charAt(0) == 'c') 
				{
					while(counter <= parts.length-1) 
					{
						if(parts[counter-1].charAt(0) == 'c') 
						{
							graph.vertices[Integer.valueOf(parts[0].replace("c", "")) + 7].addAdjacent(graph.vertices[Integer.valueOf(parts[counter-1].replace("c", "")) + 7], Integer.valueOf(parts[counter]));
						}
						else if(parts[counter-1].equals("KL")) 
						{
							graph.vertices[Integer.valueOf(parts[0].replace("c", "")) + 7].addAdjacent(graph.vertices[vertexNumber-1], Integer.valueOf(parts[counter]));
						}
						counter += 2;
					}
				}
			}
			// Adding roads.
		}
		
		FordFulkerson fordFulkerson = new FordFulkerson();
		int maxFlow = fordFulkerson.fordFulkerson(graph, 0, graph.verticesNumber-1);
		String strFlow = String.valueOf(maxFlow);
		fWriter.write(strFlow);;
		fWriter.close();
		bReader.close();
		
		
	} 
}
