import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Project1 
{
    public static void main(String[] args) 
    {
        FactoryImpl list = new FactoryImpl();
		try 
		{
			Scanner sc = new Scanner(new File(args[0]));
			FileWriter myWriter = new FileWriter(args[1]);
			// Scans input and output.
			
			while (sc.hasNextLine()) 
			{
				String word = sc.nextLine();
				String[] parts = word.split(" ");
				Boolean nextLineFlag = true;
				// Reads the line and stores elements in an array.
				if (parts[0].equals("RF")) 
				{
					try 
					{
						myWriter.write(list.removeFirst().toString());
					}
					catch (NoSuchElementException e) 
					{
						myWriter.write("Factory is empty.");
					}
					// Calls the removeFirst method form FactoryImpl.
				}
				else if (parts[0].equals("P")) 
				{
					myWriter.write(list.toString());
					// Calls the  toString method form FactoryImpl.
				}
				else if (parts[0].equals("RL")) 
				{
					try 
					{
						myWriter.write(list.removeLast().toString());
					}
					catch (NoSuchElementException e) 
					{
						myWriter.write("Factory is empty.");
					}
					// // Calls the removeLast method form FactoryImpl.
				}
				else if (parts[0].equals("AF")) 
				{
					String strId = parts[1];
					String strValue = parts[2];
					try 
					{
						int id = Integer.parseInt(strId);
						Integer value = Integer.valueOf(strValue);
						list.addFirst(new Product(id, value));
						nextLineFlag = false;
					}
					catch (NumberFormatException e) 
					{
						e.printStackTrace();
					}
					// Calls the addFirst method form FactoryImpl.
					// Converting nextLineFlag to false for not passing to the next line in output folder.
				}
				else if (parts[0].equals("A")) 
				{
					String strIndex = parts[1];
					String strId = parts[2];
					String strValue = parts[3];
					try 
					{
						int index = Integer.parseInt(strIndex);
						int id = Integer.parseInt(strId);
						Integer value = Integer.valueOf(strValue);
						list.add(index, new Product(id, value));
						nextLineFlag = false;
					}
					catch (IndexOutOfBoundsException e) 
					{
						myWriter.write("Index out of bounds.");
					}
					// Calls the add method form FactoryImpl.
					// Converting nextLineFlag to false for not passing to the next line in output folder.
				}
				else if (parts[0].equals("AL")) 
				{
					String strId = parts[1];
					String strValue = parts[2];
					try 
					{
						int id = Integer.parseInt(strId);
						Integer value = Integer.valueOf(strValue);
						list.addLast(new Product(id, value));
						nextLineFlag = false;
					}
					catch (NumberFormatException e) {
						e.printStackTrace();
					}
					// Calls the addLast method form FactoryImpl.
					// Converting nextLineFlag to false for not passing to the next line in output folder.
				}
				else if (parts[0].equals("F")) 
				{
					String strId = parts[1];
					try 
					{
						int id = Integer.parseInt(strId);
						myWriter.write(list.find(id).toString());
					}
					catch (NoSuchElementException e) 
					{
						myWriter.write("Product not found.");
					}
					// Calls the find method form FactoryImpl.	
				}
				else if (parts[0].equals("U")) 
				{
					String strId = parts[1];
					String strNewValue = parts[2];
					try 
					{
						int id = Integer.parseInt(strId);
						Integer newValue = Integer.valueOf(strNewValue);
						myWriter.write(list.update(id, newValue).toString());	
					}
					catch (NoSuchElementException e) 
					{
						myWriter.write("Product not found.");
					}
					// Calls the update method form FactoryImpl.
				}
				else if (parts[0].equals("G")) 
				{
					String strIndex = parts[1];
					try 
					{
						int index = Integer.parseInt(strIndex);
						myWriter.write(list.get(index).toString());
					}
					catch (IndexOutOfBoundsException e) 
					{
						myWriter.write("Index out of bounds.");
					}
					// Calls the get method form FactoryImpl.
				}
				else if (parts[0].equals("FD")) 
				{
					myWriter.write(((Integer)list.filterDuplicates()).toString());
					// Calls the filterDuplicates method form FactoryImpl.
					
				}
				else if (parts[0].equals("R")) 
				{
					list.reverse();
					myWriter.write(list.toString());
					// Calls the reverse method form FactoryImpl.
					// Prints the linked list to the output folder.
				}
				else if (parts[0].equals("RP")) 
				{
					String strValue = parts[1];
					try 
					{
						Integer value = Integer.valueOf(strValue);
						myWriter.write(list.removeProduct(value).toString());
					}
					catch (NoSuchElementException e) 
					{
						myWriter.write("Product not found.");
					}
					// Calls the reverse method form FactoryImpl.
				}
				else if (parts[0].equals("RI")) 
				{
					String strIndex = parts[1];
					try 
					{
						int index = Integer.parseInt(strIndex);
						myWriter.write(list.removeIndex(index).toString());
					}
					catch (IndexOutOfBoundsException e) 
					{
						myWriter.write("Index out of bounds.");
					}
					// Calls the removeIndex method form FactoryImpl.
				}
				else 
				{
					continue;
				}
				if(nextLineFlag) 
				{
				myWriter.write("\r\n");
				// Code block for deciding the pass or not to pass to the next line.
				}
				
			}
			myWriter.close();
			sc.close();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
       
        
        
    }


}