import java.util.ArrayList;
import java.util.Comparator;

class Flight
{
	public int admissionTime;
	public String flightCode;
	public ACC acc;
	public String departureAirport;
	public String arrivalAirport;
	public ArrayList<Integer> operations = new ArrayList<>();
	public boolean firstAdmission = true;

	public Flight(int admissionTime, String flightCode, ACC acc, String departureAirport, String arrivalAirport, ArrayList<Integer> operations) 
	{
		super();
		this.admissionTime = admissionTime;
		this.flightCode = flightCode;
		this.acc = acc;
		this.departureAirport = departureAirport;
		this.arrivalAirport = arrivalAirport;
		this.operations = operations;
	}
	// Flight class constructor that has admission time, flightCode, ACC that responsible from flight, airports that flight arrives/departs, and operation times ArrayList.
	
}

class FlightComparator implements Comparator<Flight>
{
	// Comparator class for flight. Used for storing flights in Priority queue.
	// readyQueues in ACCs
	public int compare(Flight f1, Flight f2) 
	{
		if(f1.admissionTime < f2.admissionTime) 
		{
			return -1;
		}
		else if (f1.admissionTime > f2.admissionTime) 
		{
			return 1;
		}
		// Comparing flight's admission times, one with smaller admission time has priority.
		else
		{
			if(f1.firstAdmission == false && f2.firstAdmission == true) 
			{
				return 1;
			}
			else if(f2.firstAdmission == false && f1.firstAdmission == true) 
			{
				return -1;
			}
			// Flights that will undergo their first admission to an ACC operation has priority.
			else
			{
				if((f1.flightCode.compareTo(f2.flightCode)) < 0) 
				{
					return -1;
				}
				else 
				{
					return 1;
				}
			}
			// Flights with smaller flightCode has priority.
		}
	}
}

