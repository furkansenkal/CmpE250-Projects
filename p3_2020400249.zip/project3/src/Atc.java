
class Atc
{
	public String name;
	public Acc acc;
	public int atcTime = 0;
	
	public Atc(String name, Acc acc) 
	{
		super();
		this.name = name;
		this.acc = acc;
	}
	// ATC class constructor with name and corresponding ACC 
	
	public void atcOperator(Flight flight) 
	{
	
		int tempAdmission;
		if(flight.operations.size()%2==0)
		// ATC running operation
		{
			if(flight.admissionTime > atcTime) 
			{
				tempAdmission = flight.admissionTime;
				// ATC is not busy
			}
			else 
			{
				tempAdmission = atcTime;
				// ATC busy
			}
			
			flight.admissionTime = tempAdmission+flight.operations.get(0);
			atcTime = tempAdmission + flight.operations.get(0);
			flight.operations.remove(0);
			// Operation finished, flight's and ATC's time increased.
			
		}
		else
		// ATC waiting operation
		{
			flight.admissionTime += flight.operations.get(0);
			flight.operations.remove(0);
			// Operation finished, flight's time increased.
		}

	}

}