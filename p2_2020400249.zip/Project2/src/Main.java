import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main 
{

	public static void main(String[] args) throws IOException 
	{
		BsTree bst = new BsTree();
		AvlTree avl = new AvlTree();
			Scanner sc = new Scanner(new File(args[0]));
			FileWriter bstWriter = new FileWriter(args[1] + "_BST.txt");
			FileWriter avlWriter = new FileWriter(args[1] +  "_AVL.txt");
			// Scans input and output.
			
			while (sc.hasNextLine()) 
			{
				String line = sc.nextLine();
				String[] parts = line.split(" ");
				// Reads the line and stores elements in an array.
				if(parts.length == 1) 
				{
					bst.addNode(parts[0]);
					avl.addNode(parts[0]);
				}
				// If the line starts with "ADDNODE" adds the node with given ip to trees and logs the necessary messages to the output files.
				else if (parts[0].equals("ADDNODE")) 
				{
					ArrayList<String> path = bst.addNode(parts[1]);
					for (int i=0; i < path.size()-1; i++) 
					{
						bstWriter.write(path.get(i)+": New node being added with IP:"+parts[1]);
						bstWriter.write("\r\n");
					}
					
					ArrayList<ArrayList<String>> avlList = avl.addNode(parts[1]);
					ArrayList<String> avlPath = avlList.get(1);
					ArrayList<String> rotation = avlList.get(0);
					
					for (int i=0; i < avlPath.size(); i++) 
					{
						avlWriter.write(avlPath.get(i)+": New node being added with IP:"+parts[1]);
						avlWriter.write("\r\n");
					}
					if(!rotation.isEmpty()) 
					{
						avlWriter.write("Rebalancing: " + rotation.get(0) + " rotation");
						avlWriter.write("\r\n");
					}
					
				}
				// If the line starts with "DELETE" deletes the node with given ip from trees and logs the necessary messages to the output files.
				else if (parts[0].equals("DELETE")) 
				{	
					bstWriter.write(bst.delete(parts[1]));
					bstWriter.write("\r\n");
					if(parts[1].equals(avl.root.getIpAdress()))
						continue;
					avlWriter.write(avl.delete(parts[1]));
					avlWriter.write("\r\n");
					
				}
				// If the line starts with "SEND" finds node-to-node path with methods and uses this paths elements to log the necessary messages to the output file.
				else if (parts[0].equals("SEND")) 
				{
					ArrayList<String> realPath = bst.send(parts[1], parts[2]);
					bstWriter.write(realPath.get(0) + ": Sending message to: " + realPath.get(realPath.size()-1));
					bstWriter.write("\r\n");
					for(int i = 1; i < realPath.size()-1; i++) 
					{
						bstWriter.write(realPath.get(i) + ": Transmission from: " + realPath.get(i-1) + " receiver: " + realPath.get(realPath.size()-1) + " sender:" + realPath.get(0));
						bstWriter.write("\r\n");
					}
					bstWriter.write(realPath.get(realPath.size()-1) + ": Received message from: " + realPath.get(0));
					bstWriter.write("\r\n");
					
					ArrayList<String> avlRealPath = avl.send(parts[1], parts[2]);
					avlWriter.write(avlRealPath.get(0) + ": Sending message to: " + avlRealPath.get(avlRealPath.size()-1));
					avlWriter.write("\r\n");
					for(int i = 1; i < avlRealPath.size()-1; i++) 
					{
						avlWriter.write(avlRealPath.get(i) + ": Transmission from: " + avlRealPath.get(i-1) + " receiver: " + avlRealPath.get(avlRealPath.size()-1) + " sender:" + avlRealPath.get(0));
						avlWriter.write("\r\n");
					}
					avlWriter.write(avlRealPath.get(avlRealPath.size()-1) + ": Received message from: " + avlRealPath.get(0));
					avlWriter.write("\r\n");
				}

			}
			bstWriter.close();
			avlWriter.close();
			sc.close();
		
	}

}
