import java.util.ArrayList;
import java.util.List;

public class Graph 
{
	public int verticesNumber = 0;
	public int counter = 0;
	public Vertex[] vertices;
	// Graph class with ArrayList to store vertices.

	public Graph(int verticesNumber)
	{
		this.verticesNumber = verticesNumber;
		this.vertices = new Vertex[verticesNumber];
		
	}

	public void addVertex(Vertex vertex) 
	{
		vertices[this.counter] = vertex;
		this.counter += 1;
	}
	// Function for adding vertex.
}
