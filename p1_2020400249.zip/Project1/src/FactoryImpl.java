import java.awt.im.InputMethodHighlight;
import java.util.NoSuchElementException;
import java.util.concurrent.CountDownLatch;

import javax.lang.model.element.NestingKind;
import javax.print.attribute.Size2DSyntax;

public class FactoryImpl implements Factory
{
	private Holder first;
	private Holder last;
	private Integer size = 0;
	
	public void addFirst(Product product) 
	{
		Holder newHolder = new Holder(null, product, null);
		
		if (first == null)
		{
			
			first = newHolder;
			last = newHolder;
			size += 1;
		}
		else 
		{
			newHolder.setNextHolder(first);
			first.setPreviousHolder(newHolder);
			first = newHolder;
			size += 1;
		}
		// Method for adding an element to the linked list to front.
	}
	
	public void addLast(Product product) 
	{
		Holder newHolder = new Holder(null, product, null);
		last = first;
		if(first == null) 
		{
			first = newHolder;
			last = newHolder;
			size += 1;
		}
		else
		{
			while(last.getNextHolder() != null) 
			{
				last = last.getNextHolder();
			}
			last.setNextHolder(newHolder);
			newHolder.setPreviousHolder(last);
			last = newHolder;
			size += 1;
		}
		// Method for adding an element to the linked list to back.
	}
	
	public Product removeFirst() throws NoSuchElementException
	{
		try 
		{
			if(first == null)
			{
				throw new NoSuchElementException();
			}
			else if(first.getNextHolder() == null) 
			{
				Product product = first.getProduct();
				first = null;
				last = null;
				size -= 1;
				return product;
			}
			else
			{
				Product product = first.getProduct();
				first = first.getNextHolder();
				first.setPreviousHolder(null);
				size -= 1;
				return product;
			}
		}
		catch (NoSuchElementException e) 
		{
			throw new NoSuchElementException();
		}
		// Method for removing an element from the linked list from front.
	}
	
	public Product removeLast() throws NoSuchElementException
	{
		
		try
		{
			last = first;
			if(first == null) 
			{
				throw new NoSuchElementException();
			}
			else if(first.getNextHolder() == null) 
			{
				Product product = first.getProduct();
				first = null;
				last = null;
				size -= 1;
				return product;
			}
			else 
			{
				while(last.getNextHolder() != null) 
				{
					last = last.getNextHolder();
				}
				Product product = last.getProduct();
				last = last.getPreviousHolder();
				last.setNextHolder(null);
				size -= 1;
				return product;
			}
		}
		catch (NoSuchElementException e) 
		{
			throw new NoSuchElementException();
		}
		// Method for removing an element from the linked list from back.
	}
	public Product find(int id) throws NoSuchElementException
	{
			Holder tempHolder = first;
			while (tempHolder!= null) 
			{
				if( id == (tempHolder.getProduct().getId())) 
				{
					return tempHolder.getProduct();
				}
				else 
				{
					tempHolder = tempHolder.getNextHolder();
				}
			}
			throw new NoSuchElementException();
			// Method for finding an element from its id.
	}
		
	public Product update(int id, Integer value) throws NoSuchElementException
	{
		Holder tempHolder = first;
		while (tempHolder!= null) 
		{
			if( id == (tempHolder.getProduct().getId())) 
			{
				Product preProduct = new Product(id, tempHolder.getProduct().getValue());
				tempHolder.getProduct().setValue(value);
				return preProduct;
			}
			else 
			{
				tempHolder = tempHolder.getNextHolder();
			}
		}
		throw new NoSuchElementException();	
		// Method for updating an elements value.
	}
	
	public Product get(int index) throws IndexOutOfBoundsException
	{
		
		int count = 0;
		Holder tempHolder = first;
		while (tempHolder != null) 
		{
			if (count == index) 
			{
				return tempHolder.getProduct();
			}
			else 
			{
				tempHolder = tempHolder.getNextHolder();
				count += 1;
			}
		}
		throw new IndexOutOfBoundsException();
		// Method for getting the element at the given index.
	}
	public void add(int index, Product product) throws IndexOutOfBoundsException
	{
		if(index>size) 
		{
			throw new IndexOutOfBoundsException();
		}
		else if(first == null) 
		{
			Holder newHolder = new Holder(null, product, null);
			first = newHolder;
			last = newHolder;
			size += 1;
		}
		else if (index == size) 
		{
			last = first;
			while(last.getNextHolder() != null) 
			{
				last = last.getNextHolder();
			}
			Holder newHolder = new Holder(last, product, null);
			last.setNextHolder(newHolder);
			last = newHolder;
			size += 1;
		}
		else if (index == 0) 
		{
			Holder newHolder = new Holder(null, product, first);
			first.setPreviousHolder(newHolder);
			first = newHolder;
			size += 1;
		}
		else
		{
			int count = 0;
			Holder tempHolder = first;
			while (tempHolder != null) 
			{
				if (count == index) 
				{
					Holder anotherHolder = tempHolder.getPreviousHolder();
					Holder newHolder = new Holder(anotherHolder, product, tempHolder);
					anotherHolder.setNextHolder(newHolder);
					tempHolder.setPreviousHolder(newHolder);
					size += 1;
				}
					
				tempHolder = tempHolder.getNextHolder();
				count += 1;
			}
		}
		// Method for adding an element to the given index.
	}
	
	public Product removeIndex(int index) throws IndexOutOfBoundsException
	{
		
		int count = 0;
		Holder tempHolder = first;
		if (first == null) 
		{
			throw new IndexOutOfBoundsException();
		}
		else if(index>=size) 
		{
			throw new IndexOutOfBoundsException();
		}
		while (tempHolder != null) 
		{
			if (count == index) 
			{
				Holder prevHolder = tempHolder.getPreviousHolder();
				Holder nextHolder = tempHolder.getNextHolder();
				Product product = tempHolder.getProduct();
				if(nextHolder == null && prevHolder != null) 
				{
					prevHolder.setNextHolder(null);
					last = prevHolder;
				}
				else if(prevHolder == null && nextHolder != null) 
				{
					nextHolder.setPreviousHolder(null);
					first = nextHolder;
				}
				else if(prevHolder == null && nextHolder == null)
				{
					first = null;
					last = null;
				}
				else 
				{
					prevHolder.setNextHolder(nextHolder);
					nextHolder.setPreviousHolder(prevHolder);
				}
				tempHolder = null;
				size -= 1;
				return product;
			}
			else 
			{
				tempHolder = tempHolder.getNextHolder();
				count += 1;
			}
		}
		throw new IndexOutOfBoundsException();
		// Method for removing the element at the given index.
	}
	
	public Product removeProduct(int value) throws NoSuchElementException
	{
		
		Holder tempHolder = first;
		while (tempHolder!= null)	
			if( value == (tempHolder.getProduct().getValue())) 
			{
				Holder prevHolder = tempHolder.getPreviousHolder();
				Holder nextHolder = tempHolder.getNextHolder();
				Product product = tempHolder.getProduct();
				if(nextHolder == null && prevHolder != null) 
				{
					prevHolder.setNextHolder(null);
					last = prevHolder;
				}
				else if(prevHolder == null && nextHolder != null) 
				{
					nextHolder.setPreviousHolder(null);
					first = nextHolder;
				}
				else if(prevHolder == null && nextHolder == null)
				{
					first = null;
					last = null;
				}
				else 
				{
					prevHolder.setNextHolder(nextHolder);
					nextHolder.setPreviousHolder(prevHolder);
				}
				tempHolder = null;
				size -= 1;
				return product;
				
			}
			else 
			{
				tempHolder = tempHolder.getNextHolder();
			}
		throw new NoSuchElementException();
		// Method for removing the first element that has the given value.
	}
	
	public int filterDuplicates() 
	{
		int dupCounter = 0;
		Holder tempHolder = first;
		while((tempHolder != null) && (tempHolder.getNextHolder() != null))
		{
			Holder tempHolder2 = tempHolder.getNextHolder();
			while(tempHolder2 != null) 
			{
				if(tempHolder2.getProduct().getValue() == tempHolder.getProduct().getValue()) 
				{
					if(tempHolder2.getNextHolder() == null) 
					{
						tempHolder2.getPreviousHolder().setNextHolder(null);
					}
					else if(tempHolder2.getPreviousHolder() == null)
					{
						tempHolder2.getNextHolder().setPreviousHolder(null);
					}
					else 
					{
						tempHolder2.getNextHolder().setPreviousHolder(tempHolder2.getPreviousHolder());
						tempHolder2.getPreviousHolder().setNextHolder(tempHolder2.getNextHolder());
					}
					dupCounter += 1;
					size -= 1;
				}
				tempHolder2 = tempHolder2.getNextHolder();
			}
			tempHolder = tempHolder.getNextHolder();
		}
		return dupCounter;
		// Method for filtering duplicates.
	}
	
	public void reverse() 
	{
		Holder tempHolder = null;
		Holder currentHolder = first;
		
		while(currentHolder != null) 
		{
			tempHolder = currentHolder.getPreviousHolder();
			currentHolder.setPreviousHolder(currentHolder.getNextHolder());
			currentHolder.setNextHolder(tempHolder);
			currentHolder = currentHolder.getPreviousHolder();
			
		}
		if(tempHolder != null) 
		{
			first = tempHolder.getPreviousHolder();
		}
		// Method for reversing the list.
	}
	
	public String toString() 
	{
		String string = ""; 
		string = "{";
		if(first != null) 
		{
			Holder tempHolder = first;
			while(tempHolder != null) 
			{
				string += tempHolder;
				if(tempHolder.getNextHolder() != null) 
				{
					string += ",";
				}
				tempHolder = tempHolder.getNextHolder();
			}	
		}
		string += "}";
		return string;
		// Method for converting the linked list to a string form.
	}
}