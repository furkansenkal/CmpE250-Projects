import java.util.HashMap;

public class Vertex 
{
	public String name;
	public HashMap<Vertex, Integer> adjacents = new HashMap<>();
	// Vertex class with name and adjacents map to store roads.
	
	public Vertex(String name) 
	{
		this.name = name;
	}
	
	public void addAdjacent(Vertex vertex, int capacity) 
	{
		adjacents.put(vertex, capacity);
	}
	// Function to add adjacent.
	
}
