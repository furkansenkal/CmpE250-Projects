import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


class Project3
{
	public static void main(String[] args) throws IOException 
	{
		Scanner sc = new Scanner(new File(args[0]));
		FileWriter accWriter = new FileWriter(args[1]);
		// Opens input and output files using scanner and fileWriter.
		int lineCounter = 0;
		ArrayList<ACC> accArray = new ArrayList<>();
		int accNumber = 0;
		// Creates an ArrayList for storing ACC's
		while (sc.hasNextLine())
		{
			String line = sc.nextLine();
			String[] parts = line.split(" ");
			lineCounter += 1;
			if(lineCounter == 1) 
			{
				try 
				{
					accNumber = Integer.parseInt(parts[0]);
				}
				catch (NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			// Reading number of ACCs from first line of input.
			else if ((lineCounter > 1) && (lineCounter <= accNumber+1)) 
			{
				ArrayList<String> airports = new ArrayList<>();
				for(int i = 0; i<(parts.length-1); i++) 
				{
					airports.add(parts[i+1]);
				}
				accArray.add(0, new ACC(parts[0], airports));
				// Reading ACC lines, creating ACCs and storing them.
			}
			else if (lineCounter > accNumber+1) 
			{
				ArrayList<Integer> operations = new ArrayList<>();
				for(int i=5; i<parts.length;i++) 
				{
					try 
					{
						operations.add(Integer.parseInt(parts[i]));
					}
					catch (NumberFormatException e) 
					{
						e.printStackTrace();
					}
				}
				// Reading flight lines and storing their operations in operations ArrayList.
				for(int i=0; i<accArray.size(); i++) 
				{
					if (parts[2].equals(accArray.get(i).name)) 
					{
						int admissionTime = 0;
						try 
						{
							admissionTime = Integer.parseInt(parts[0]);
						}
						catch (NumberFormatException e) 
						{
							e.printStackTrace();
						}
						accArray.get(i).readyQueue.add(new Flight(admissionTime, parts[1], accArray.get(i), parts[3], parts[4], operations));
					}
				}
				// Creating Flights and adding them to corresponding ACC ready queue.
			}	
		}
		for(int i=accArray.size()-1; i>=0; i--) 
		{
			ACC currentAcc = accArray.get(i);
			currentAcc.enterFlight();
			// Calculates ACC finishing time.
			accWriter.write(currentAcc.name+" "+ currentAcc.time);
			// Writes to the output file.
			for(int j=0; j<currentAcc.hashAirports.length; j++) 
			{
				if (currentAcc.hashAirports[j] != null) 
				{
					if(j <= 9) 
					{
						accWriter.write(" "+currentAcc.hashAirports[j]+"00"+j);
					}
					else if((10 <= j) && (j <= 99)) 
					{
						accWriter.write(" "+currentAcc.hashAirports[j]+"0"+j);
					}
					else if(j >= 100) 
					{
						accWriter.write(" "+currentAcc.hashAirports[j]+j);
					}
				}
			}
			// Writes corresponding ACC's airports and their hash values concatenated.
			accWriter.write("\r\n");
			// Goes to next line.
		}
		accWriter.close();
		sc.close();
	}

}