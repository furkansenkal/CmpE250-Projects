
import java.util.LinkedList;

public class FordFulkerson 
{
	
	public FordFulkerson() 
	{
		super();
	}
	
	

	// Returns the maximum flow from source to sink in the given graph.
	
	public int fordFulkerson(Graph graph, int source, int sink)
	{
	    int u, v;
	    
	    // This array is filled by BFS and to store path
	    int parent[] = new int[graph.verticesNumber];
	
	    int maxFlow = 0; // There is no flow initially
	
	    // Augment the flow while there is path from source
	    // to sink
	    while (bfs(graph.vertices, source, sink, parent, graph.verticesNumber)) 
	    {
	        // Find minimum residual capacity of the edhes
	        // along the path filled by BFS. Or we can say
	        // find the maximum flow through the path found.
	        int pathFlow = Integer.MAX_VALUE;
	        
	        for (v = sink; v != source; v = parent[v]) 
	        {
	        	u = parent[v];
	        	pathFlow = Math.min(pathFlow, graph.vertices[u].adjacents.get(graph.vertices[v]));
	
	        // update residual capacities of the edges and
	        // reverse edges along the path
	        }
	        for (v = sink; v != source; v = parent[v]) 
	        {
	            u = parent[v];
	            int old = graph.vertices[u].adjacents.get(graph.vertices[v]);
	            graph.vertices[u].adjacents.put(graph.vertices[v], old - pathFlow);
	            graph.vertices[v].adjacents.put(graph.vertices[u], old + pathFlow);
	        }
	
	        // Add path flow to overall flow
	        maxFlow += pathFlow;
	    }
	
	    // Return the overall flow
	    return maxFlow;
	}
	
	
	boolean bfs(Vertex[] vertices, int source, int sink, int parent[], int verticesNumber)
	{
		// Create a visited array and mark all vertices as not visited
		boolean visited[] = new boolean[verticesNumber];
		for (int i = 0; i < verticesNumber; ++i)
			visited[i] = false;

	    // Create a queue, enqueue source vertex and mark source vertex as visited
	    LinkedList<Integer> queue = new LinkedList<Integer>();
	    queue.add(source);
	    visited[source] = true;
	    parent[source] = -1;
	
	    // Standard BFS Loop
	    while (queue.size() != 0) 
	    {
	        int u = queue.poll();
	
	        for (int v = 0; v < verticesNumber; v++) 
	        {
	            if (visited[v] == false && vertices[u].adjacents.getOrDefault(vertices[v], 0) > 0) 
	            {
	                // If we find a connection to the sink node, then there is no point in BFSanymore 
	            	// We just have to set its parent and can return true
	                if (v == sink)
	                {
	                    parent[v] = u;
	                    return true;
	                }
	                
	                queue.add(v);
	                parent[v] = u;
	                visited[v] = true;
	            }
	        }
	    }
	    // We didn't reach sink in BFS starting from source,
	    // so return false
	    return false;
	}
}